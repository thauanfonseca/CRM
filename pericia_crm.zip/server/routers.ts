import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  getPericiasByUser,
  getPericiaById,
  createPericia,
  updatePericia,
  deletePericia,
  getAssistenciasByUser,
  createAssistencia,
  getClientesByUser,
  createCliente,
  getEspecialistasByUser,
  createEspecialista,
  getTarefasByUser,
  createTarefa,
  getRelatoriosByUser,
  createRelatorio,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Perícias
  pericias: router({
    list: protectedProcedure.query(({ ctx }) =>
      getPericiasByUser(ctx.user.id)
    ),
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => getPericiaById(input.id)),
    create: protectedProcedure
      .input(
        z.object({
          titulo: z.string().min(1),
          processo: z.string().min(1),
          tipo: z.string().optional(),
          valor: z.number().optional(),
          autora: z.string().optional(),
          re: z.string().optional(),
          descricao: z.string().optional(),
          prazo: z.date().optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        createPericia({
          userId: ctx.user.id,
          ...input,
        })
      ),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          titulo: z.string().optional(),
          status: z.enum(["em_andamento", "concluida", "pendente"]).optional(),
          tipo: z.string().optional(),
          valor: z.number().optional(),
          autora: z.string().optional(),
          re: z.string().optional(),
          descricao: z.string().optional(),
          prazo: z.date().optional(),
        })
      )
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return updatePericia(id, data);
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deletePericia(input.id)),
  }),

  // Assistências
  assistencias: router({
    list: protectedProcedure.query(({ ctx }) =>
      getAssistenciasByUser(ctx.user.id)
    ),
    create: protectedProcedure
      .input(
        z.object({
          titulo: z.string().min(1),
          processo: z.string().min(1),
          valor: z.number().optional(),
          descricao: z.string().optional(),
          prazo: z.date().optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        createAssistencia({
          userId: ctx.user.id,
          ...input,
        })
      ),
  }),

  // Clientes
  clientes: router({
    list: protectedProcedure.query(({ ctx }) =>
      getClientesByUser(ctx.user.id)
    ),
    create: protectedProcedure
      .input(
        z.object({
          nome: z.string().min(1),
          email: z.string().email().optional(),
          telefone: z.string().optional(),
          endereco: z.string().optional(),
          descricao: z.string().optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        createCliente({
          userId: ctx.user.id,
          ...input,
        })
      ),
  }),

  // Especialistas
  especialistas: router({
    list: protectedProcedure.query(({ ctx }) =>
      getEspecialistasByUser(ctx.user.id)
    ),
    create: protectedProcedure
      .input(
        z.object({
          nome: z.string().min(1),
          email: z.string().email().optional(),
          telefone: z.string().optional(),
          especialidade: z.string().optional(),
          registroProfissional: z.string().optional(),
          endereco: z.string().optional(),
          descricao: z.string().optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        createEspecialista({
          userId: ctx.user.id,
          ...input,
        })
      ),
  }),

  // Tarefas
  tarefas: router({
    list: protectedProcedure.query(({ ctx }) =>
      getTarefasByUser(ctx.user.id)
    ),
    create: protectedProcedure
      .input(
        z.object({
          titulo: z.string().min(1),
          descricao: z.string().optional(),
          prioridade: z.enum(["baixa", "media", "alta"]).optional(),
          pericias_id: z.number().optional(),
          prazo: z.date().optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        createTarefa({
          userId: ctx.user.id,
          ...input,
        })
      ),
  }),

  // Relatórios
  relatorios: router({
    list: protectedProcedure.query(({ ctx }) =>
      getRelatoriosByUser(ctx.user.id)
    ),
    create: protectedProcedure
      .input(
        z.object({
          titulo: z.string().min(1),
          tipo: z.string().optional(),
          conteudo: z.string().optional(),
          pericias_id: z.number().optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        createRelatorio({
          userId: ctx.user.id,
          ...input,
        })
      ),
  }),
});

export type AppRouter = typeof appRouter;
