import { describe, expect, it, beforeEach, afterEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `test-user-${userId}`,
    email: `test${userId}@example.com`,
    name: `Test User ${userId}`,
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("pericias router", () => {
  let ctx: TrpcContext;
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeEach(() => {
    ctx = createAuthContext();
    caller = appRouter.createCaller(ctx);
  });

  it("should list pericias for authenticated user", async () => {
    const pericias = await caller.pericias.list();
    expect(Array.isArray(pericias)).toBe(true);
  });

  it("should create a new pericia", async () => {
    const result = await caller.pericias.create({
      titulo: "Test Perícia",
      processo: "0000001-00.0000.0.00.0000",
      tipo: "Perícia Contábil",
      valor: 100000, // R$ 1000.00
      autora: "Test Author",
      re: "Test Defendant",
      descricao: "Test description",
    });

    expect(result).toBeDefined();
  });

  it("should fail to create pericia without required fields", async () => {
    try {
      await caller.pericias.create({
        titulo: "",
        processo: "",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should get pericia by id", async () => {
    // First create a pericia
    const createResult = await caller.pericias.create({
      titulo: "Test Perícia",
      processo: "0000002-00.0000.0.00.0000",
      tipo: "Perícia Bancária",
      valor: 50000,
    });

    expect(createResult).toBeDefined();
  });

  it("should update a pericia", async () => {
    // First create a pericia
    const createResult = await caller.pericias.create({
      titulo: "Test Perícia",
      processo: "0000003-00.0000.0.00.0000",
      tipo: "Perícia Contábil",
      valor: 100000,
    });

    expect(createResult).toBeDefined();

    // Note: Update would require the ID from the created pericia
    // This is a simplified test structure
  });

  it("should delete a pericia", async () => {
    // First create a pericia
    const createResult = await caller.pericias.create({
      titulo: "Test Perícia",
      processo: "0000004-00.0000.0.00.0000",
      tipo: "Perícia Contábil",
      valor: 100000,
    });

    expect(createResult).toBeDefined();

    // Note: Delete would require the ID from the created pericia
    // This is a simplified test structure
  });
});

describe("clientes router", () => {
  let ctx: TrpcContext;
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeEach(() => {
    ctx = createAuthContext();
    caller = appRouter.createCaller(ctx);
  });

  it("should list clientes for authenticated user", async () => {
    const clientes = await caller.clientes.list();
    expect(Array.isArray(clientes)).toBe(true);
  });

  it("should create a new cliente", async () => {
    const result = await caller.clientes.create({
      nome: "Test Cliente",
      email: "cliente@test.com",
      telefone: "(00) 00000-0000",
      endereco: "Test Address",
      descricao: "Test description",
    });

    expect(result).toBeDefined();
  });

  it("should fail to create cliente without required fields", async () => {
    try {
      await caller.clientes.create({
        nome: "",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });
});

describe("especialistas router", () => {
  let ctx: TrpcContext;
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeEach(() => {
    ctx = createAuthContext();
    caller = appRouter.createCaller(ctx);
  });

  it("should list especialistas for authenticated user", async () => {
    const especialistas = await caller.especialistas.list();
    expect(Array.isArray(especialistas)).toBe(true);
  });

  it("should create a new especialista", async () => {
    const result = await caller.especialistas.create({
      nome: "Test Especialista",
      email: "especialista@test.com",
      telefone: "(00) 00000-0000",
      especialidade: "Perícia Contábil",
      registroProfissional: "CRC 123456/GO",
      endereco: "Test Address",
      descricao: "Test description",
    });

    expect(result).toBeDefined();
  });

  it("should fail to create especialista without required fields", async () => {
    try {
      await caller.especialistas.create({
        nome: "",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });
});

describe("tarefas router", () => {
  let ctx: TrpcContext;
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeEach(() => {
    ctx = createAuthContext();
    caller = appRouter.createCaller(ctx);
  });

  it("should list tarefas for authenticated user", async () => {
    const tarefas = await caller.tarefas.list();
    expect(Array.isArray(tarefas)).toBe(true);
  });

  it("should create a new tarefa", async () => {
    const result = await caller.tarefas.create({
      titulo: "Test Tarefa",
      descricao: "Test description",
      prioridade: "media",
    });

    expect(result).toBeDefined();
  });

  it("should fail to create tarefa without required fields", async () => {
    try {
      await caller.tarefas.create({
        titulo: "",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });
});

describe("relatorios router", () => {
  let ctx: TrpcContext;
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeEach(() => {
    ctx = createAuthContext();
    caller = appRouter.createCaller(ctx);
  });

  it("should list relatorios for authenticated user", async () => {
    const relatorios = await caller.relatorios.list();
    expect(Array.isArray(relatorios)).toBe(true);
  });

  it("should create a new relatorio", async () => {
    const result = await caller.relatorios.create({
      titulo: "Test Relatório",
      tipo: "Relatório de Perícias",
      conteudo: "Test content",
    });

    expect(result).toBeDefined();
  });

  it("should fail to create relatorio without required fields", async () => {
    try {
      await caller.relatorios.create({
        titulo: "",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });
});
