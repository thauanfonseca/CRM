import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { CheckCircle2, Plus } from "lucide-react";
import { toast } from "sonner";

export default function Tarefas() {
  const { isAuthenticated } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    titulo: "",
    descricao: "",
    prioridade: "media" as "baixa" | "media" | "alta",
  });

  const { data: tarefas = [], refetch } = trpc.tarefas.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const createMutation = trpc.tarefas.create.useMutation({
    onSuccess: () => {
      toast.success("Tarefa criada com sucesso!");
      setFormData({
        titulo: "",
        descricao: "",
        prioridade: "media",
      });
      setIsDialogOpen(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao criar tarefa");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const getPriorityColor = (prioridade: string) => {
    switch (prioridade) {
      case "alta":
        return "bg-destructive/20 text-destructive border border-destructive/30";
      case "media":
        return "bg-orange/20 text-orange border border-orange/30";
      case "baixa":
        return "bg-green/20 text-green border border-green/30";
      default:
        return "bg-muted/20 text-muted-foreground border border-muted/30";
    }
  };

  const getPriorityLabel = (prioridade: string) => {
    switch (prioridade) {
      case "alta":
        return "Alta";
      case "media":
        return "Média";
      case "baixa":
        return "Baixa";
      default:
        return prioridade;
    }
  };

  const tarefasPendentes = tarefas.filter((t) => t.status === "pendente");
  const tarefasEmProgresso = tarefas.filter((t) => t.status === "em_progresso");
  const tarefasConcluidas = tarefas.filter((t) => t.status === "concluida");

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
            <CheckCircle2 className="w-8 h-8 text-primary" />
            Minhas Tarefas
          </h1>
          <p className="text-muted-foreground mt-1">
            Gerencie suas tarefas e acompanhe o progresso.
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2">
              <Plus className="w-4 h-4" />
              Nova Tarefa
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="text-foreground">Nova Tarefa</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground">Título *</label>
                <Input
                  placeholder="Título da tarefa"
                  value={formData.titulo}
                  onChange={(e) => setFormData({ ...formData, titulo: e.target.value })}
                  className="bg-input border-border text-foreground"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Descrição</label>
                <textarea
                  placeholder="Descrição da tarefa"
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  className="w-full bg-input border border-border text-foreground rounded-md p-2"
                  rows={3}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Prioridade</label>
                <select
                  value={formData.prioridade}
                  onChange={(e) => setFormData({ ...formData, prioridade: e.target.value as "baixa" | "media" | "alta" })}
                  className="w-full bg-input border border-border text-foreground rounded-md p-2"
                >
                  <option value="baixa">Baixa</option>
                  <option value="media">Média</option>
                  <option value="alta">Alta</option>
                </select>
              </div>
              <div className="flex gap-2 justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                  className="border-border text-foreground hover:bg-card"
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? "Criando..." : "Criar Tarefa"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-card border-border p-4">
          <p className="text-sm text-muted-foreground">Total</p>
          <p className="text-2xl font-bold text-primary">{tarefas.length}</p>
        </Card>
        <Card className="bg-card border-border p-4">
          <p className="text-sm text-muted-foreground">Pendentes</p>
          <p className="text-2xl font-bold text-orange">{tarefasPendentes.length}</p>
        </Card>
        <Card className="bg-card border-border p-4">
          <p className="text-sm text-muted-foreground">Em Progresso</p>
          <p className="text-2xl font-bold text-accent">{tarefasEmProgresso.length}</p>
        </Card>
        <Card className="bg-card border-border p-4">
          <p className="text-sm text-muted-foreground">Concluídas</p>
          <p className="text-2xl font-bold text-[#00D084]">{tarefasConcluidas.length}</p>
        </Card>
      </div>

      {/* Tarefas por Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pendentes */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold text-foreground">Pendentes ({tarefasPendentes.length})</h2>
          {tarefasPendentes.length === 0 ? (
            <Card className="bg-card border-border p-4 text-center">
              <p className="text-muted-foreground text-sm">Nenhuma tarefa pendente</p>
            </Card>
          ) : (
            tarefasPendentes.map((tarefa) => (
              <Card key={tarefa.id} className="bg-card border-border p-4 hover:bg-card/80 transition-colors">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground">{tarefa.titulo}</h3>
                    {tarefa.descricao && <p className="text-xs text-muted-foreground mt-1">{tarefa.descricao}</p>}
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium mt-2 ${getPriorityColor(tarefa.prioridade || "media")}`}>
                      {getPriorityLabel(tarefa.prioridade || "media")}
                    </span>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>

        {/* Em Progresso */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold text-foreground">Em Progresso ({tarefasEmProgresso.length})</h2>
          {tarefasEmProgresso.length === 0 ? (
            <Card className="bg-card border-border p-4 text-center">
              <p className="text-muted-foreground text-sm">Nenhuma tarefa em progresso</p>
            </Card>
          ) : (
            tarefasEmProgresso.map((tarefa) => (
              <Card key={tarefa.id} className="bg-card border-border p-4 hover:bg-card/80 transition-colors">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground">{tarefa.titulo}</h3>
                    {tarefa.descricao && <p className="text-xs text-muted-foreground mt-1">{tarefa.descricao}</p>}
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium mt-2 ${getPriorityColor(tarefa.prioridade || "media")}`}>
                      {getPriorityLabel(tarefa.prioridade || "media")}
                    </span>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>

        {/* Concluídas */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold text-foreground">Concluídas ({tarefasConcluidas.length})</h2>
          {tarefasConcluidas.length === 0 ? (
            <Card className="bg-card border-border p-4 text-center">
              <p className="text-muted-foreground text-sm">Nenhuma tarefa concluída</p>
            </Card>
          ) : (
            tarefasConcluidas.map((tarefa) => (
              <Card key={tarefa.id} className="bg-card border-border p-4 hover:bg-card/80 transition-colors opacity-75">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground line-through">{tarefa.titulo}</h3>
                    {tarefa.descricao && <p className="text-xs text-muted-foreground mt-1">{tarefa.descricao}</p>}
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium mt-2 ${getPriorityColor(tarefa.prioridade || "media")}`}>
                      {getPriorityLabel(tarefa.prioridade || "media")}
                    </span>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
