import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BarChart3, FileText, Users, DollarSign, CheckCircle2, Clock, AlertCircle } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const { data: pericias = [] } = trpc.pericias.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const { data: assistencias = [] } = trpc.assistencias.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Calcular métricas
  const totalPericias = pericias.length;
  const periciasConcluidas = pericias.filter((p) => p.status === "concluida").length;
  const periciaEmAndamento = pericias.filter((p) => p.status === "em_andamento").length;
  const valorTotal = pericias.reduce((sum, p) => sum + (p.valor || 0), 0);

  const totalAssistencias = assistencias.length;
  const assistenciasConcluidas = assistencias.filter((a) => a.status === "concluida").length;
  const assistenciasEmAndamento = assistencias.filter((a) => a.status === "em_andamento").length;
  const valorAssistencias = assistencias.reduce((sum, a) => sum + (a.valor || 0), 0);

  const taxaConclusao = totalPericias > 0 ? Math.round((periciasConcluidas / totalPericias) * 100) : 0;

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-foreground mb-4">Perícia Pro</h1>
          <p className="text-muted-foreground mb-8">Sistema de CRM para Gestão de Perícias Judiciais</p>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
            Fazer Login
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Olá, {user?.name} 👋</h1>
        <p className="text-muted-foreground">
          Resumo de suas perícias e assistências hoje, {new Date().toLocaleDateString("pt-BR")}
        </p>
      </div>

      {/* Perícias Judiciais */}
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <FileText className="w-6 h-6 text-primary" />
          Perícias Judiciais
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Total de Perícias */}
          <Card className="bg-card border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Total de Perícias</p>
                <p className="text-3xl font-bold text-primary">{totalPericias}</p>
                <p className="text-xs text-muted-foreground mt-2">+{totalPericias} este mês</p>
              </div>
              <FileText className="w-8 h-8 text-primary/50" />
            </div>
          </Card>

          {/* Perícias em Andamento */}
          <Card className="bg-card border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Perícias em Andamento</p>
                <p className="text-3xl font-bold text-accent">{periciaEmAndamento}</p>
                <p className="text-xs text-muted-foreground mt-2">0 pendentes</p>
              </div>
              <Clock className="w-8 h-8 text-accent/50" />
            </div>
          </Card>

          {/* Perícias Concluídas */}
          <Card className="bg-card border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Perícias Concluídas</p>
                <p className="text-3xl font-bold text-[#00D084]">{periciasConcluidas}</p>
                <p className="text-xs text-muted-foreground mt-2">{taxaConclusao}% de conclusão</p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-[#00D084]/50" />
            </div>
          </Card>

          {/* Honorários */}
          <Card className="bg-card border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Honorários (Perícias)</p>
                <p className="text-3xl font-bold text-secondary">
                  R$ {(valorTotal / 100).toLocaleString("pt-BR")}
                </p>
                <p className="text-xs text-muted-foreground mt-2">Valor total estimado</p>
              </div>
              <DollarSign className="w-8 h-8 text-secondary/50" />
            </div>
          </Card>
        </div>
      </div>

      {/* Assistências Técnicas */}
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <Users className="w-6 h-6 text-secondary" />
          Assistências Técnicas
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Total de Assistências */}
          <Card className="bg-card border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Total de Assistências</p>
                <p className="text-3xl font-bold text-secondary">{totalAssistencias}</p>
                <p className="text-xs text-muted-foreground mt-2">+{totalAssistencias} este mês</p>
              </div>
              <Users className="w-8 h-8 text-secondary/50" />
            </div>
          </Card>

          {/* Assistências em Andamento */}
          <Card className="bg-card border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Assistências em Andamento</p>
                <p className="text-3xl font-bold text-accent">{assistenciasEmAndamento}</p>
                <p className="text-xs text-muted-foreground mt-2">0 pendentes</p>
              </div>
              <Clock className="w-8 h-8 text-accent/50" />
            </div>
          </Card>

          {/* Assistências Concluídas */}
          <Card className="bg-card border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Assistências Concluídas</p>
                <p className="text-3xl font-bold text-[#00D084]">{assistenciasConcluidas}</p>
                <p className="text-xs text-muted-foreground mt-2">
                  {totalAssistencias > 0 ? Math.round((assistenciasConcluidas / totalAssistencias) * 100) : 0}% de conclusão
                </p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-[#00D084]/50" />
            </div>
          </Card>

          {/* Honorários Assistências */}
          <Card className="bg-card border-border p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Honorários (Assistências)</p>
                <p className="text-3xl font-bold text-secondary">
                  R$ {(valorAssistencias / 100).toLocaleString("pt-BR")}
                </p>
                <p className="text-xs text-muted-foreground mt-2">Valor total estimado</p>
              </div>
              <DollarSign className="w-8 h-8 text-secondary/50" />
            </div>
          </Card>
        </div>
      </div>

      {/* Progresso Geral */}
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-primary" />
          Progresso Geral (Todos)
        </h2>
        <Card className="bg-card border-border p-6">
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-foreground">Taxa de Conclusão (Todos)</p>
                <p className="text-sm font-bold text-primary">{taxaConclusao}%</p>
              </div>
              <div className="w-full bg-border rounded-full h-2">
                <div
                  className="bg-primary h-2 rounded-full transition-all"
                  style={{ width: `${taxaConclusao}%` }}
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-[#00D084]">{periciasConcluidas + assistenciasConcluidas}</p>
                <p className="text-xs text-muted-foreground">Serviços Concluídos</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-accent">{periciaEmAndamento + assistenciasEmAndamento}</p>
                <p className="text-xs text-muted-foreground">Serviços em Andamento</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-secondary">
                  R$ {((valorTotal + valorAssistencias) / 100).toLocaleString("pt-BR")}
                </p>
                <p className="text-xs text-muted-foreground">Valor Total (Global)</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
