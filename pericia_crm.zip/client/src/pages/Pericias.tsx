import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { FileText, Plus, Trash2, Edit2, Eye } from "lucide-react";
import { toast } from "sonner";

export default function Pericias() {
  const { isAuthenticated } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    titulo: "",
    processo: "",
    tipo: "",
    valor: 0,
    autora: "",
    re: "",
    descricao: "",
  });

  const { data: pericias = [], refetch } = trpc.pericias.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const createMutation = trpc.pericias.create.useMutation({
    onSuccess: () => {
      toast.success("Perícia criada com sucesso!");
      setFormData({
        titulo: "",
        processo: "",
        tipo: "",
        valor: 0,
        autora: "",
        re: "",
        descricao: "",
      });
      setIsDialogOpen(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao criar perícia");
    },
  });

  const deleteMutation = trpc.pericias.delete.useMutation({
    onSuccess: () => {
      toast.success("Perícia deletada com sucesso!");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao deletar perícia");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate({
      ...formData,
      valor: Math.round(formData.valor * 100),
    });
  };

  const filteredPericias = pericias.filter(
    (p) =>
      p.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.processo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "em_andamento":
        return "bg-cyan/20 text-cyan border border-cyan/30";
      case "concluida":
        return "bg-green/20 text-green border border-green/30";
      case "pendente":
        return "bg-orange/20 text-orange border border-orange/30";
      default:
        return "bg-muted/20 text-muted-foreground border border-muted/30";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "em_andamento":
        return "Em Andamento";
      case "concluida":
        return "Concluída";
      case "pendente":
        return "Pendente";
      default:
        return status;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
            <FileText className="w-8 h-8 text-primary" />
            Gestão de Perícias
          </h1>
          <p className="text-muted-foreground mt-1">
            Gerencie todas as suas perícias judiciais em um só lugar.
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2">
              <Plus className="w-4 h-4" />
              Nova Perícia
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="text-foreground">Nova Perícia</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground">Título *</label>
                <Input
                  placeholder="Ex: Perícia Contábil - Processo XYZ"
                  value={formData.titulo}
                  onChange={(e) => setFormData({ ...formData, titulo: e.target.value })}
                  className="bg-input border-border text-foreground"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Processo *</label>
                <Input
                  placeholder="Ex: 0000522-36.2006.8.05.0120"
                  value={formData.processo}
                  onChange={(e) => setFormData({ ...formData, processo: e.target.value })}
                  className="bg-input border-border text-foreground"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Tipo</label>
                <Input
                  placeholder="Ex: Perícia Contábil"
                  value={formData.tipo}
                  onChange={(e) => setFormData({ ...formData, tipo: e.target.value })}
                  className="bg-input border-border text-foreground"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Valor (R$)</label>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={formData.valor}
                  onChange={(e) => setFormData({ ...formData, valor: parseFloat(e.target.value) || 0 })}
                  className="bg-input border-border text-foreground"
                  step="0.01"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground">Autora</label>
                  <Input
                    placeholder="Nome da autora"
                    value={formData.autora}
                    onChange={(e) => setFormData({ ...formData, autora: e.target.value })}
                    className="bg-input border-border text-foreground"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Ré</label>
                  <Input
                    placeholder="Nome da ré"
                    value={formData.re}
                    onChange={(e) => setFormData({ ...formData, re: e.target.value })}
                    className="bg-input border-border text-foreground"
                  />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Descrição</label>
                <textarea
                  placeholder="Descrição da perícia"
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  className="w-full bg-input border border-border text-foreground rounded-md p-2"
                  rows={3}
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                  className="border-border text-foreground hover:bg-card"
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? "Criando..." : "Criar Perícia"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filters */}
      <div className="flex gap-4">
        <Input
          placeholder="Buscar por título, processo, partes do processo o..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1 bg-input border-border text-foreground"
        />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-card border-border p-4">
          <p className="text-sm text-muted-foreground">Total</p>
          <p className="text-2xl font-bold text-primary">{pericias.length}</p>
        </Card>
        <Card className="bg-card border-border p-4">
          <p className="text-sm text-muted-foreground">Em Andamento</p>
          <p className="text-2xl font-bold text-accent">
            {pericias.filter((p) => p.status === "em_andamento").length}
          </p>
        </Card>
        <Card className="bg-card border-border p-4">
          <p className="text-sm text-muted-foreground">Concluídas</p>
          <p className="text-2xl font-bold text-[#00D084]">
            {pericias.filter((p) => p.status === "concluida").length}
          </p>
        </Card>
        <Card className="bg-card border-border p-4">
          <p className="text-sm text-muted-foreground">Valor Total</p>
          <p className="text-2xl font-bold text-secondary">
            R$ {(pericias.reduce((sum, p) => sum + (p.valor || 0), 0) / 100).toLocaleString("pt-BR")}
          </p>
        </Card>
      </div>

      {/* Perícias List */}
      <div className="space-y-3">
        <h2 className="text-lg font-semibold text-foreground">Perícias ({filteredPericias.length})</h2>
        {filteredPericias.length === 0 ? (
          <Card className="bg-card border-border p-8 text-center">
            <p className="text-muted-foreground">Nenhuma perícia encontrada</p>
          </Card>
        ) : (
          filteredPericias.map((pericia) => (
            <Card key={pericia.id} className="bg-card border-border p-4 hover:bg-card/80 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-foreground">{pericia.titulo}</h3>
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(pericia.status)}`}>
                      {getStatusLabel(pericia.status)}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">Proc: {pericia.processo}</p>
                  {pericia.autora && <p className="text-sm text-muted-foreground">Autora: {pericia.autora}</p>}
                  {pericia.re && <p className="text-sm text-muted-foreground">Ré: {pericia.re}</p>}
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-secondary">R$ {(pericia.valor || 0) / 100}</p>
                  <div className="flex gap-2 mt-2">
                    <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary">
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary">
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-muted-foreground hover:text-destructive"
                      onClick={() => deleteMutation.mutate({ id: pericia.id })}
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
