import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Perícias
export const pericias = mysqlTable("pericias", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  titulo: varchar("titulo", { length: 255 }).notNull(),
  processo: varchar("processo", { length: 100 }).notNull().unique(),
  status: mysqlEnum("status", ["em_andamento", "concluida", "pendente"]).default("em_andamento").notNull(),
  tipo: varchar("tipo", { length: 100 }),
  valor: int("valor").default(0),
  autora: varchar("autora", { length: 255 }),
  re: varchar("re", { length: 255 }),
  descricao: text("descricao"),
  prazo: timestamp("prazo"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Pericia = typeof pericias.$inferSelect;
export type InsertPericia = typeof pericias.$inferInsert;

// Assistências Técnicas
export const assistencias = mysqlTable("assistencias", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  titulo: varchar("titulo", { length: 255 }).notNull(),
  processo: varchar("processo", { length: 100 }).notNull(),
  status: mysqlEnum("status", ["em_andamento", "concluida", "pendente"]).default("em_andamento").notNull(),
  valor: int("valor").default(0),
  descricao: text("descricao"),
  prazo: timestamp("prazo"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Assistencia = typeof assistencias.$inferSelect;
export type InsertAssistencia = typeof assistencias.$inferInsert;

// Clientes
export const clientes = mysqlTable("clientes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  nome: varchar("nome", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  telefone: varchar("telefone", { length: 20 }),
  endereco: text("endereco"),
  descricao: text("descricao"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Cliente = typeof clientes.$inferSelect;
export type InsertCliente = typeof clientes.$inferInsert;

// Especialistas
export const especialistas = mysqlTable("especialistas", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  nome: varchar("nome", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  telefone: varchar("telefone", { length: 20 }),
  especialidade: varchar("especialidade", { length: 255 }),
  registroProfissional: varchar("registroProfissional", { length: 100 }),
  endereco: text("endereco"),
  descricao: text("descricao"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Especialista = typeof especialistas.$inferSelect;
export type InsertEspecialista = typeof especialistas.$inferInsert;

// Tarefas
export const tarefas = mysqlTable("tarefas", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  titulo: varchar("titulo", { length: 255 }).notNull(),
  descricao: text("descricao"),
  status: mysqlEnum("status", ["pendente", "em_progresso", "concluida"]).default("pendente").notNull(),
  prioridade: mysqlEnum("prioridade", ["baixa", "media", "alta"]).default("media"),
  pericias_id: int("pericias_id").references(() => pericias.id),
  prazo: timestamp("prazo"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Tarefa = typeof tarefas.$inferSelect;
export type InsertTarefa = typeof tarefas.$inferInsert;

// Relatórios
export const relatorios = mysqlTable("relatorios", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  titulo: varchar("titulo", { length: 255 }).notNull(),
  tipo: varchar("tipo", { length: 100 }),
  conteudo: text("conteudo"),
  pericias_id: int("pericias_id").references(() => pericias.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Relatorio = typeof relatorios.$inferSelect;
export type InsertRelatorio = typeof relatorios.$inferInsert;